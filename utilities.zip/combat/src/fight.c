/*
** EPITECH PROJECT, 2025
** bnd
** File description:
** fjd
*/

#include "../include/my_enemies.h"

void start_combat_simple(int enemy_id)
{
    printf("Combat lancé avec l'ennemi");
}
